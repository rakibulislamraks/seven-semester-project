<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=n">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Rakibul blog</title>
<style>
  .img{
  width: 100%;

}
.gallery{
    margin: 30px;
}

</style>
  </head>
  <body>
    <form action=""method="POST" enctype="multipart/form-data">
        <input type="text" name="name"placeholder="your name"><br>
        <input type="file" name="image[]" multiple><br>
        <input type="submit"name="upload"value="upload">
    </form>
<?php 
if(isset($message)){
    echo $message;
}
elseif (isset($_GET['message'])){
    echo "<span style = 'color:green;'>Image uploaded...</span>";
    header("Refresh:5;url=post_img.php");
}
?>
    <?php 
        include "config.php";
        if(isset($_POST['upload'])){
        $uploadDirectory = "upload/";
        $validExtensions = array('jpg', 'jpeg', 'png', 'bmp');

        $message = $errortype = $errorSize = $errorImage = "";
        $img_ref = rand();
        $sqlValues = "";

        foreach ($_FILES['image']['tmp_name'] as $imageKey => $iamgeValue){
            $image = $_FILES['image']['name'][$imageKey];
            $imageSize = $_FILES['image']['size'][$imageKey];
            $imageTmp = $_FILES['image']['tmp_name'][$imageKey];
            $imageType = pathinfo($uploadDirectory.$image, PATHINFO_EXTENSION);

            if($image != ''){
                $imageNewName = uniqid().".".$imageType;
            }
            else{
                $imageNewName = "";
                $errorImage.="<span style = 'color:red;'>Image Required...</span>";
            }
            if($imageSize > 1024000){
                $errorSize .= "<span style = 'color:red;'>larg image size must be under 1 MB</span>";
            }
            else if(!empty($image) && !in_array($imageType, $validExtensions)){
                $errorType .= "<span style = 'color:red;'>File must be an Image</span>";
            }
            else if(empty($message)){
                $sqlValues .= "('".$imageNewName."', '".$img_ref."'),";

                $Store = move_uploaded_file($imageTmp, $uploadDirectory.$imageNewName);

            }
            
        }
        $title = mysqli_real_escape_string($conn, $_POST['name']);
       
            $SqlIns = "INSERT INTO img_user (name, img_ref) Values('{$title}','".$img_ref."');";
            $SqlIns .= "INSERT INTO images1 (image, img_ref) Values $sqlValues";

            $SqlIns = rtrim($SqlIns, ",");
            $result = mysqli_multi_query($conn, $SqlIns);
            
            if($result){
                header("Location: image.php?message = success&name=".$title."&img_ref=".$img_ref);
            }
    }

 ?>

<br><br>
<br>
<div class="gallery">


<?php
include "config.php";
    if(isset($_GET['img_ref'])){
        $sql = "SELECT * FROM images1 WHERE img_ref = '".$_GET['img_ref']."' ORDER BY img_id DESC";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
            echo '<img src="upload/'.$row['image'].'"height="300px" width="400px">';
        }
    }
    else{
        '<img src="images/ww.jpg" height="300px" width="400px" alt="">';
    }
    ?>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
