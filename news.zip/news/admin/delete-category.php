<?php
include "config.php";

if($_SESSION['user_role']=='0'){
    header("Location: {$hostname}/admin/post.php");
}

$userid = $_GET['id'];

$sql = "DELETE FROM category WHERE category_id = {$userid}";

if(mysqli_query($conn, $sql)){
    header("Location:{$hostname}/admin/category.php");
}else{
    echo "can't delete user record";
}
mysqli_close($conn);

?>