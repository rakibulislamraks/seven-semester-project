<?php
include "config.php";

if(empty($_FILES['new-image']['name'])){
    $file_name = $_POST['old-image'];
}else{
    $errors = array();

    $file_name =$_FILES['new-image']['name'];
    $file_size =$_FILES['new-image']['size'];
    $file_tmp = $_FILES['new-image']['tmp_name'];
    $file_type = $_FILES['new-image']['type'];
    $file_ext = strtolower(end(explode('.',$file_name)));
    $extensions = array("jpeg","jpg","png");

    if(in_array($file_ext,$extensions)== false){
        $errors[] = "this extension file not allowed ,please choose a png or jpg file";
    }
    
    if($file_size > 2097152){
        $errors[] = "File  size must be 2mb or lower";
    }
    if(empty($errors) == true){
        move_uploaded_file($file_tmp,"upload/".$file_name);
    }else{
        print_r($errors);
        die();
    }
}
 $sql = "UPDATE setting SET website_name='{$_POST["post_title"]}',website_desc='{$_POST["post_desc"]}',footer_des='{$_POST["postdesc"]}',logo ='{$file_name}'";

 $result = mysqli_multi_query($conn, $sql);
if($result){
    header("Location: {$hostname}/admin/post.php");

}
else{
    echo "setting query failed";
}
?>