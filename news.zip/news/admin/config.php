<?php 
    $hostname = "http://localhost/news";

    $conn = mysqli_connect("localhost","root","","hasib") or die("connection field" .mysqli_connect_error());

?>