<?php include "header.php";
if($_SESSION['user_role']=='0'){
    header("Location: {$hostname}/admin/post.php");
}

?>
<div id="admin-content">
  <div class="container">
  <div class="row">
    <div class="col-md-12">
        <h1 class="admin-heading">Website setting</h1>
    </div>
    <div class="col-md-offset-3 col-md-6">
    <?php
            include "config.php";

            $sql = "SELECT * FROM setting";

                $result = mysqli_query($conn ,$sql) or die("query failed");
                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_assoc($result)){

               
        ?>
        <!-- Form for show edit-->
        <form action="save-setting.php" method="POST" enctype="multipart/form-data" autocomplete="off">
            <div class="form-group">
                <input type="hidden" name="post_id"  class="form-control" value="<?php echo $row['website_name']; ?>" placeholder="">
            </div>
            
            <div class="form-group">
                <label for="exampleInputTile">Website Name</label>
                <input type="text" name="post_title"  class="form-control" id="exampleInputUsername" value="<?php echo $row['website_name']; ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputTile">Website Description</label>
                <input type="text" name="post_desc"  class="form-control" id="exampleInputUsername" value="<?php echo $row['website_desc']; ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1"> Description</label>
                <textarea name="postdesc" class="form-control"  required rows="5">
                <?php echo $row['footer_des']; ?>
                </textarea>
            </div>
            <div class="form-group">
             
            </div>
            <div class="form-group">
                <label for="">Logo</label>
                <input type="file" name="new-image">
                <img  src="upload/<?php echo $row['logo'];?>" height="150px">
                <input type="hidden" name="old-image" value="<?php echo $row['logo']; ?>">
            </div>
            <input type="submit" name="submit" class="btn btn-primary" value="Update" />
        </form>
       <?php }
                }
                ?>
        <!-- Form End -->
      </div>
    </div>
  </div>
</div>
<?php include "footer.php"; ?>
