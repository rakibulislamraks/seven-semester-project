<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .txt{
            position: absolute;
            top:70px;
            left: 100px;
            color: white;
        }
        .img{
            width: 100%;
            height:350px;
        }
    </style>
</head>
<body>
    <?php 
            include "config.php";
            $sql = "SELECT * FROM setting";
            $result = mysqli_query($conn, $sql) or die("query failed");
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){


              
    ?>
    <div class="txt">
        <h1><?php echo $row['website_name']; ?></h1>
        <P><?php echo $row['website_desc']; ?></P>
        <a class="btn btn-warning" href="admin/index.php"target="blank">LOGIN</a>
        <a class="btn btn-info" href="sign-up.php">Sign-up</a>
    </div>
    <?php include "config.php";?>
    <a href="<?php echo $hostname;?>">
    <img class="img" src="admin/upload/<?php echo $row['logo']; ?>" alt="">

    </a>
    <?php 
          }
        }
    ?>
</body>
</html>