<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <?php
            include "config.php";

            $sql = "SELECT * FROM setting";

                $result = mysqli_query($conn ,$sql) or die("query failed");
                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_assoc($result)){
                        if($row['logo']==""){
                            echo '<a href="index.php"><h1>'.$row['website_name'].'</h1></a>';
                        }
                        else{
                            echo '<span>'.$row['footer_des'].'</span>';
                
                        }
               
        ?>
                <?php }
                } ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
