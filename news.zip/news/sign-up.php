<?php include 'feature.php'; ?>
<?php include 'header.php'; 

include "config.php";

if(isset($_POST['save'])){
    include "config.php";

    $fname = mysqli_real_escape_string($conn,$_POST['fname']);
    $lname = mysqli_real_escape_string($conn,$_POST['lname']);
    $user = mysqli_real_escape_string($conn,$_POST['user']);
    $password = mysqli_real_escape_string($conn,md5($_POST['password']));
    $role = mysqli_real_escape_string($conn,$_POST['role']);

    $sql = "SELECT username FROM user WHERE username = '{$user}'";
    $result = mysqli_query($conn, $sql) or die("query field");
    
    if(mysqli_num_rows($result) > 0){
        echo "<h1>user name already used</h1>";
    }
    else{
        $sql1 = "INSERT INTO user(first_name,last_name,username,password,role) 
                VALUES('{$fname}','{$lname}','{$user}','{$password}','{$role}')";
        if(mysqli_query($conn, $sql1)){
            header("Location: index.php");
        }
}

}


?>
    <div id="main-content">
      <div class="container">
        <div class="row">
            <div class="col-md-8">
                <!-- post-container -->
                <div class="post-container">
                <div class="col-md-12">
                  <h1 class="admin-heading">SIGN UP PAGE</h1><br>
              </div>
                <form  action="<?php $_SERVER['PHP_SELF']; ?>" method ="POST" autocomplete="off">
                      <div class="form-group">
                          <label>First Name</label>
                          <input type="text" name="fname" class="form-control" placeholder="First Name" required>
                      </div>
                          <div class="form-group">
                          <label>Last Name</label>
                          <input type="text" name="lname" class="form-control" placeholder="Last Name" required>
                      </div>
                      <div class="form-group">
                          <label>User Name</label>
                          <input type="text" name="user" class="form-control" placeholder="Username" required>
                      </div>

                      <div class="form-group">
                          <label>Password</label>
                          <input type="password" name="password" class="form-control" placeholder="Password" required>
                      </div>
                      <div class="form-group">
                          <label>User Role</label>
                          <select class="form-control" name="role" >
                              <option value="0">User</option>
                              <!-- <option value="1">Admin</option> -->
                          </select>
                      </div>
                      <input type="submit"  name="save" class="btn btn-primary" value="sign-up" required />
                  </form>
                </div><!-- /post-container -->
            </div>
            <?php include 'sidebar.php'; ?>
        </div>
      </div>
    </div>
<?php include 'footer.php'; ?>
